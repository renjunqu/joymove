package com.joymove.test;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.sql.ResultSet;

import org.springframework.util.FileCopyUtils;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class Image {
	public static void main(String[] args) throws Exception {

		BigDecimal q = new BigDecimal("0.0100000");
		BigDecimal q1 = new BigDecimal(0.01);
		System.out.println(q.doubleValue() >= q1.doubleValue());
		 //PrintWriter printWriter = new PrintWriter(fileOutputStream);
	}
}
































