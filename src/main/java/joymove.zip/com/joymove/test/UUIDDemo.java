package com.joymove.test;

import java.util.UUID;

public class UUIDDemo {

	public static void main(String [] args) {
		String uuid = String.valueOf(UUID.randomUUID());
		System.out.println(uuid);
	}
}
