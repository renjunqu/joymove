package com.joymove.test;

public class TestFormat {
	
	public  static void main(String[] args){
		Integer ttt = Integer.parseInt("abc",10);  
		System.out.println(ttt);
		
		
	
	}

}
